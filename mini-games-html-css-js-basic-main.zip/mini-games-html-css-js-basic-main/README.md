# mini-games-html-css-js-basic

this code is just for education and entertainment 👌

tutorial on my youtube:
https://youtu.be/dk2DdKh2uQI
